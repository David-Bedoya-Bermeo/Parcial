<?php 
  header('Access-Control-Allow-Origin: *'); 
  header("Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept");
  
  $json = file_get_contents('php://input');
 
  $params = json_decode($json);
  
  require("conexion.php");
  $con=retornarConexion();
  
//No olvidar poner las (,)
  mysqli_query($con,"update articulos set nombre='$params->nombre',
                                          apellido='$params->apellido',
                                          cedula='$params->cedula',
                                          eps='$params->eps',
                                          neuroVegetativo='$params->neuroVegetativo',
                                          trastornoConciencia='$params->trastornoConciencia',
                                          deshidratacion='$params->deshidratacion',
                                          sepsis='$params->sepsis',
                                          patologias='$params->patologias',
                                          examen='$params->examen',
                                          nivel='$params->nivel',
                                          descripcion='$params->descripcion'
                                          where codigo=$params->codigo");
                                          
  class Result {}

  $response = new Result();
  $response->resultado = 'OK';
  $response->mensaje = 'datos modificados';

  header('Content-Type: application/json');
  echo json_encode($response);  
?>