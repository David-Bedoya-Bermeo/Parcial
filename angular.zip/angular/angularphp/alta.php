<?php 
  header('Access-Control-Allow-Origin: *'); 
  header("Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept");
  
  $json = file_get_contents('php://input');
 
  $params = json_decode($json);
  
  require("conexion.php");
  $con=retornarConexion();
  

  mysqli_query($con,"insert into articulos(nombre,apellido,cedula,eps,neuroVegetativo,trastornoConciencia,deshidratacion,sepsis,patologias,examen,nivel,descripcion) values
                  ('$params->nombre','$params->apellido','$params->cedula','$params->eps','$params->neuroVegetativo','$params->trastornoConciencia',
                  '$params->deshidratacion','$params->sepsis','$params->patologias','$params->examen','$params->nivel','$params->descripcion')");
          
  class Result {}

  $response = new Result();
  $response->resultado = 'OK';
  $response->mensaje = 'datos grabados';

  header('Content-Type: application/json');
  echo json_encode($response);  
?>