<?php
function retornarConexion() {
  $con=mysqli_connect("localhost","root","","db2");
  return $con;
}
?>